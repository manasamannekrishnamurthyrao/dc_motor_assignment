#include<lpc214x.h>
void isr_eint1(void)__irq;
void delay(void);
void interruptinit(void);

int main()
{
int i=0;
IODIR0=1<<4|1<<15;
interruptinit();
do{i=i;
i=i;
}while(1);
}

void interruptinit(void)
{
PINSEL0=(PINSEL0&~(3<<28)) | 1<<29;
VICIntEnable = 1<<15;   // Enabling the External Interrupt EINT1 by writing 1 to 15th bit
VICIntSelect = 0<<15;   // Writing 0 will make it as IRQ, Writing 1 will make it as FIQ
VICVectCntl0 = 15|1<<5; //isr address is stored here
VICVectAddr0 = (long)isr_eint1;    // 
EXTMODE=(1<<1); // To decide between edge & Level  // Writing 1 Edge // writing 0 level
EXTPOLAR=(0<<1); //If Edge is Selected Raising or Falling // If Level is Selected Active Low or Active High // Writing 1 is Rising or Active Low // Writing 0 is Falling or Active High
while(1);
}

void isr_eint1()__irq
{
int i;
IODIR0= (1<<15)|1<<4;
for(i=0;i<=3;i++)
{
IOSET0= (1<<15)|1<<4;
delay();
IOCLR0= (1<<15)|1<<4;
delay();
}
EXTINT = (1<<1);
VICVectAddr =0;	//VICVectAddr =0;
}

void delay()
{
int i, j;
for(i=0;i<=1000;i++)
for(j=0;j<=1000;j++);
}
